#include "/lib/settings.glsl"
#include "/lib/uniforms2.glsl"
#include "/lib/shadow_param.glsl"
#include "/lib/taa/res_params.glsl"


#include "/lib/color_transforms.glsl"
#ifndef NO_PROJECT
#include "/lib/projections.glsl"
#endif
#include "/lib/functions.glsl"

#include "/lib/noise.glsl"