#version 140 compatibility 
#extension GL_ARB_shader_texture_lod : enable
#extension GL_ARB_shader_bit_encoding : enable
#define NETHER
#include "/includes/main.glsl"

#define ENTITY

#ifdef PBR
#include "/program/gbuffers/solid/gbuffers_complex.fsh"
#else
#include "/program/gbuffers/solid/gbuffers_med.fsh"
#endif

