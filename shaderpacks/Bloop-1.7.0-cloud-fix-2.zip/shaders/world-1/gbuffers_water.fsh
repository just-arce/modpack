#version 140 compatibility
#define NETHER
#define WATER

#include "/includes/main.glsl"

#include "/program/gbuffers/translucent/gbuffers_water.fsh"

