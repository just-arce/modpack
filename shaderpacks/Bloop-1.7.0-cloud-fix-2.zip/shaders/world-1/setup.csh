#version 430 compatibility

#define RENDER_SETUP
#define NO_PROJECT

#include "/includes/main.glsl"

#include "/program/lpv/setup.csh"
