#version 140 compatibility
#define NETHER
#include "/includes/main.glsl"

#include "/program/gbuffers/translucent/gbuffers_simple_translucent.vsh"

