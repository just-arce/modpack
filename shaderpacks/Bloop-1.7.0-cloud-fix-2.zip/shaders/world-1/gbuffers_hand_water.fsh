#version 140 compatibility
#define NETHER
#include "/includes/main.glsl"

#define COMPLEX_NORMALS
#include "/program/gbuffers/translucent/gbuffers_simple_translucent.fsh"

