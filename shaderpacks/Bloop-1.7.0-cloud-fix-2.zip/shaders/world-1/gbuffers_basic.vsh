#version 140 compatibility
#include "/includes/main.glsl"

#include "/program/gbuffers/solid/gbuffers_simple.vsh"
