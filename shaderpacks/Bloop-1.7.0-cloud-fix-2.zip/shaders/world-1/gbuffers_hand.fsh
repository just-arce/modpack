#version 140 compatibility
#extension GL_ARB_shader_bit_encoding : enable

#define NETHER
#include "/includes/main.glsl"

#define COMPLEX_NORMALS
#include "/program/gbuffers/solid/gbuffers_med.fsh"

