#version 140 compatibility
#define END
#include "/includes/main.glsl"

#define LEAVES

#ifdef PBR
#include "/program/gbuffers/solid/gbuffers_complex.vsh"
#else
#include "/program/gbuffers/solid/gbuffers_med.vsh"
#endif
