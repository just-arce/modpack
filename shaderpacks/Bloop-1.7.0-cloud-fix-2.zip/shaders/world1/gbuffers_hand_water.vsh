#version 140 compatibility
#define END
#include "/includes/main.glsl"

#define COMPLEX_NORMALS
#include "/program/gbuffers/translucent/gbuffers_simple_translucent.vsh"

