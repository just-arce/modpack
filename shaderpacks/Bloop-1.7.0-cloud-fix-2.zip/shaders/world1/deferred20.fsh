#version 140 compatibility
#define END
#include "/includes/main.glsl"

#include "/program/effects/ssr.fsh"

