#version 140 compatibility
#define END
#include "/includes/main.glsl"

#include "/program/gbuffers/solid/gbuffers_sun.vsh"

