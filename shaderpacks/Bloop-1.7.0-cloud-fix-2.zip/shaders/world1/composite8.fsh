#version 140 compatibility
#extension GL_ARB_texture_gather : enable
#define STAGE0
#include "/includes/main.glsl"

#include "/program/effects/bloom.fsh"

