#version 140 compatibility
#define END
#include "/includes/main.glsl"

#include "/program/fog_translucent.vsh"

