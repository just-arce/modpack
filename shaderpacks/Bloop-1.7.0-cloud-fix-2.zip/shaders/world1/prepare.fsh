#version 140 compatibility
#define END
#define altnoise

#include "/includes/main.glsl"

#include "/program/skyfog.fsh"

