varying vec2 texcoord;

void main()
{
    texcoord.xy = gl_MultiTexCoord0.xy;

    gl_Position = ftransform();
}
