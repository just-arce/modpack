


varying vec4 color;
varying float NdotL;

flat varying vec3 torch;
varying vec2 texcoord;



/* DRAWBUFFERS:1*/
void main()
{

    vec4 color = texture(texture, texcoord.xy) * color;
    float diffuseSun = mix(0.0, NdotL, min(eyeBrightnessSmooth.y / 240.0, 1.0));

    color.rgb = toLinear(color.rgb) * (sunLight * diffuseSun + (luma(atmosphereUp) * 2.0) + torch);

    gl_FragData[0] = color;
}
