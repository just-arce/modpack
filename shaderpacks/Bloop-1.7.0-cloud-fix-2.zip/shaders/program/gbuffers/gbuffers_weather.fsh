

varying vec4 color;
varying float NdotL;

flat varying vec3 torch;
varying vec2 lmtexcoord;

/* DRAWBUFFERS:1*/
void main()
{

    vec4 color = texture(texture, lmtexcoord.xy) * color;
    color.a *= 0.5;

    color.rgb = toLinear(color.rgb) * (sunLight * NdotL + atmosphereUp + torch);

    gl_FragData[0] = color;
}
