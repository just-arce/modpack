varying vec4 color;
varying vec2 texcoord;

#define diagonal3(m) vec3((m)[0].x, (m)[1].y, m[2].z)
#define projMAD(m, v) (diagonal3(m) * (v) + (m)[3].xyz)

void main()
{
    texcoord.xy = (gl_TextureMatrix[0] * gl_MultiTexCoord0).st;

    color = gl_Color;

    color.rgb *= 1.25;

    vec3 position = mat3(gl_ModelViewMatrix) * gl_Vertex.xyz + gl_ModelViewMatrix[3].xyz;

    gl_Position = taaFunc(toClipSpace4(position));
}
