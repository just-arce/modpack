

varying vec4 color;
varying vec2 lmtexcoord;

#define diagonal3(m) vec3((m)[0].x, (m)[1].y, m[2].z)
#define projMAD(m, v) (diagonal3(m) * (v) + (m)[3].xyz)

void main()
{
    lmtexcoord.xy = vec2(gl_MultiTexCoord0.xy);

    color = gl_Color;

    vec4 viewPos = gl_ModelViewMatrix * gl_Vertex;
    gl_Position = taaFunc(vec4(diagonal3(gl_ProjectionMatrix) * viewPos.xyz + gl_ProjectionMatrix[3].xyz, -viewPos.z));

}
