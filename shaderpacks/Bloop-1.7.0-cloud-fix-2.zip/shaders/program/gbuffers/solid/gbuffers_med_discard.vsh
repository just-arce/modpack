





varying vec4 lmtexcoord;
varying vec4 color;







#define diagonal3(m) vec3((m)[0].x, (m)[1].y, m[2].z)
#define projMAD(m, v) (diagonal3(m) * (v) + (m)[3].xyz)

void main()
{
    lmtexcoord.xyzw = vec4(gl_MultiTexCoord0.xy, (gl_MultiTexCoord1.xy * recip));
    color = gl_Color;

    vec3 position = mat3(gl_ModelViewMatrix) * gl_Vertex.xyz + gl_ModelViewMatrix[3].xyz;

    gl_Position =  taaFunc(toClipSpace4(position));
}
