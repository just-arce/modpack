

varying vec4 color;
varying vec2 texcoord;

/* DRAWBUFFERS:0*/
void main()
{
    vec4 texColor = texture(texture, texcoord.xy);
    gl_FragData[0] = vec4(toLinear(texColor.rgb * color.rgb), texColor.a * color.a);
}
