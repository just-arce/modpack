

varying vec4 lmtexcoord;
varying vec4 color;

/* DRAWBUFFERS:05*/
void main()
{

    vec4 albedo = texture(texture, lmtexcoord.xy, 0);
    if (luma(albedo.rgb) == 0 || albedo.a == 0)
        discard;
    albedo.rgb = toLinear(albedo.rgb * color.rgb);

    gl_FragData[0] = albedo; // Albedo

    gl_FragData[1] = vec4(0, 1, 0, 0.07);
}
