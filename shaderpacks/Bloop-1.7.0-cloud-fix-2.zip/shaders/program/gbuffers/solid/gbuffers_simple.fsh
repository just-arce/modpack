varying vec4 color;
varying vec2 lmtexcoord;

#ifdef SIMPLE
    #ifdef LITEMATICA
    /* DRAWBUFFERS:01*/
    #else
    /* DRAWBUFFERS:0*/
    #endif
#else
/* DRAWBUFFERS:0*/
#endif

void main()
{

    vec4 albedo = texture(texture, lmtexcoord);
    albedo.rgb = toLinear(albedo.rgb * color.rgb);
#ifdef SIMPLE
    albedo.a *= color.a;
#endif

    // discard;
    gl_FragData[0] = albedo;
}