#version 140 compatibility
#define OVERWORLD

#include "/includes/main.glsl"

#include "/program/gbuffers/solid/gbuffers_sky.fsh"
