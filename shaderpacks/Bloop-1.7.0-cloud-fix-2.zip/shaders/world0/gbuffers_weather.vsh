#version 140 compatibility
#define OVERWORLD

#include "/includes/main.glsl"

#include "/program/gbuffers/gbuffers_weather.vsh"
