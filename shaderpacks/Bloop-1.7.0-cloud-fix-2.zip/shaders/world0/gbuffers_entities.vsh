#version 140 compatibility
#define OVERWORLD
#include "/includes/main.glsl"

#define COMPLEX_NORMALS
#define ENTITY

#define ENTITY
#ifdef PBR
    #ifdef LAB_PBR
        #include "/program/gbuffers/solid/gbuffers_complex.vsh"
    #else
        #include "/program/gbuffers/solid/gbuffers_complex_entity.vsh"

    #endif
#else
    #include "/program/gbuffers/solid/gbuffers_med.vsh"
#endif
