#version 140 compatibility
#include "/includes/main.glsl"
#define OVERWORLD


#extension GL_EXT_gpu_shader4 : enable

varying vec4 lmtexcoord;
varying vec4 color;
varying vec3 viewVector;






void main()
{
    /* DRAWBUFFERS:0*/

    // vec4 color = vec4(toLinear(texture(tex, lmtexcoord.xy).rgb * color.rgb) * lmtexcoord.w +   toLinear(texture(tex,
    // lmtexcoord.xy).rgb * color.rgb) * lmtexcoord.z,  texture(tex, lmtexcoord.xy).a);
    vec4 color = texture(tex, lmtexcoord.xy) * color;
#ifndef SHADOW_DEBUG

    if (length(viewVector) < min(0.8 * far, shadowDistance * 0.8))
    {
        discard;
    }
#endif
#ifdef SHADOW_DEBUG

    color.rgb *= vec3(0.1, 0.1, 1.0);
#endif
    gl_FragData[0] = vec4(color);
    // discard;
    //  gl_FragData[0].a = float(color.a >= noise_standard(gl_FragCoord.xy)*0.5);
}
