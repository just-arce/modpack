#version 140 compatibility 
#extension GL_ARB_shader_texture_lod : enable
#extension GL_ARB_shader_bit_encoding : enable

#define OVERWORLD
#define WATER
#define DH

#include "/includes/main.glsl"

#include "/program/gbuffers/dh/gbuffers_dh_water.fsh"

