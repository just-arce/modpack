#version 140 compatibility
#include "/includes/main.glsl"
#define OVERWORLD

// #include "/program/gbuffers/discard.vsh"
#include "/program/gbuffers/dh/gbuffers_clouds.vsh"
