#version 140 compatibility
#define OVERWORLD
#include "/includes/main.glsl"

#define COMPLEX_NORMALS

#include "/program/gbuffers/solid/gbuffers_med.vsh"
