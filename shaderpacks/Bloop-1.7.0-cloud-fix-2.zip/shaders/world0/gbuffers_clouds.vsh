#version 140 compatibility
#define OVERWORLD

#include "/includes/main.glsl"

// #include "/program/gbuffers/discard.vsh"
#include "/program/gbuffers/translucent/gbuffers_clouds.vsh"
