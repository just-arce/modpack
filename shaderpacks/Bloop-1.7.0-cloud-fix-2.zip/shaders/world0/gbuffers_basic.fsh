#version 140 compatibility
#extension GL_ARB_shader_bit_encoding : enable
#define OVERWORLD
#include "/includes/main.glsl"

#define SIMPLE
#include "/program/gbuffers/solid/gbuffers_simple.fsh"

