#version 140 compatibility
#define OVERWORLD
#define altnoise
#include "/includes/main.glsl"

#ifdef ALT_CLOUDS

#include "/program/clouds_alt.fsh"
#else
#include "/program/clouds.fsh"

#endif